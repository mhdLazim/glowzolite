<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep product data in `src/lib/products.ts` so detail pages, cards, and order calculations use one catalog.
- Keep the temporary shopping cart in a root React provider so selections survive navigation without storing customer data or requiring accounts.
- Define the cart context and hook outside UI modules so live component refreshes cannot create a second context and disconnect consumers from the mounted provider.
- Serve responsive WebP product and homepage images through asset pointers; preserve transparent cut-outs and prioritize the homepage cover to reduce loading time.
