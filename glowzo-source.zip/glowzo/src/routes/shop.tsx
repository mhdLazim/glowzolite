import { createFileRoute } from "@tanstack/react-router";
import { Footer, Header, ProductCard, products, meta } from "@/components/site";

export const Route = createFileRoute("/shop")({
  head: () => meta("Shop — Glowzo", "Shop Glowzo Ayurvedic brightening oil, hair growth serum and skin brightening pack."),
  component: Shop,
});

function Shop() {
  return (
    <main className="min-h-screen bg-background font-sans text-foreground">
      <Header />
      <section className="mx-auto max-w-7xl px-6 pb-24 pt-12 md:px-10">
        <p className="text-xs uppercase tracking-widest text-accent">Shop</p>
        <h1 className="mb-4 mt-3 font-display text-5xl md:text-6xl">All Products</h1>
        <div className="mb-12" />
        <div className="grid gap-10 md:grid-cols-3">
          {products.map((p) => <ProductCard key={p.name} p={p} />)}
        </div>
      </section>
      <Footer />
    </main>
  );
}
