import { createFileRoute, Link } from "@tanstack/react-router";
import { Sparkle, Play, Pause } from "lucide-react";
import { useRef, useState } from "react";
import hero from "@/assets/hero-product-1600.webp.asset.json";
import heroSmall from "@/assets/hero-product-800.webp.asset.json";
import launch from "@/assets/launch.mp4.asset.json";
import skintone from "@/assets/skintone.mp4.asset.json";
import brighten from "@/assets/brighten.mp4.asset.json";
import { BRAND, Footer, Header, ProductCard, products, meta } from "@/components/site";

export const Route = createFileRoute("/")({
   head: () => ({
     ...meta("Glowzo — Ayurvedic Skin & Hair Care", "Glowzo Lite brightening oil, hair growth serum and skin brightening pack, made with Ayurvedic herbs."),
     links: [{ rel: "preload", as: "image", href: hero.url, imageSrcSet: `${heroSmall.url} 800w, ${hero.url} 1200w`, imageSizes: "100vw", fetchPriority: "high" }],
   }),
  component: Index,
});

const videos = [
  { src: brighten.url, label: "Reduce fine lines" },
  { src: skintone.url, label: "Even skin tone" },
  { src: launch.url, label: "Now launching" },
];

function RitualVideo({ src, label, playing, videoRef, onToggle }: { src: string; label: string; playing: boolean; videoRef: (el: HTMLVideoElement | null) => void; onToggle: () => void }) {
  return (
    <div className="overflow-hidden rounded-3xl border border-border">
      <button type="button" onClick={onToggle} aria-label={playing ? `Pause ${label}` : `Play ${label}`} className="relative block w-full cursor-pointer">
        <video ref={videoRef} src={`${src}#t=0.1`} loop playsInline preload="metadata" className="aspect-[9/16] w-full object-cover" />
        <span className={`absolute inset-0 flex items-center justify-center bg-background/30 transition-opacity ${playing ? "opacity-0 hover:opacity-100" : "opacity-100"}`}>
          <span className="grid h-16 w-16 place-items-center rounded-full border border-border bg-background/70 backdrop-blur">
            {playing ? <Pause className="h-6 w-6 text-foreground" /> : <Play className="ml-1 h-6 w-6 text-foreground" />}
          </span>
        </span>
      </button>
      <p className="px-5 py-4 text-xs uppercase tracking-widest text-muted-foreground">{label}</p>
    </div>
  );
}

function Rituals() {
  const [active, setActive] = useState<number | null>(null);
  const refs = useRef<(HTMLVideoElement | null)[]>([]);

  const toggle = (i: number) => {
    const v = refs.current[i];
    if (!v) return;
    if (active === i) {
      v.pause();
      setActive(null);
      return;
    }
    // Pause whichever video is currently playing so only one plays at a time.
    refs.current.forEach((el) => el?.pause());
    v.muted = false;
    v.play().catch(() => {});
    setActive(i);
  };

  return (
    <div className="grid gap-6 sm:grid-cols-3">
      {videos.map((v, i) => (
        <RitualVideo
          key={v.label}
          src={v.src}
          label={v.label}
          playing={active === i}
          videoRef={(el) => { refs.current[i] = el; }}
          onToggle={() => toggle(i)}
        />
      ))}
    </div>
  );
}

function Index() {
  return (
    <main className="min-h-screen bg-background font-sans text-foreground">
      <section className="relative isolate overflow-hidden">
        <img src={hero.url} srcSet={`${heroSmall.url} 800w, ${hero.url} 1200w`} sizes="100vw" fetchPriority="high" decoding="async" alt="Glowzo Lite Brightening Oil resting on driftwood" width={1200} height={896} className="absolute inset-0 -z-10 h-full w-full object-cover object-[35%_center]" />
        <div className="absolute inset-0 -z-10 bg-gradient-to-r from-background/30 via-transparent to-background/80" />
        <div className="absolute inset-x-0 bottom-0 -z-10 h-40 bg-gradient-to-b from-transparent to-background" />
        <Header />
        <div className="mx-auto flex min-h-[62vh] max-w-7xl flex-col justify-between gap-10 px-4 pb-12 sm:px-6 md:px-10 lg:min-h-[70vh]">
          <h1 className="animate-rise select-none text-right font-display text-[13vw] leading-none text-secondary/90 lg:text-[10rem]">{BRAND}</h1>
          <div className="ml-auto max-w-sm space-y-6 text-right">
            <p className="text-base text-secondary sm:text-lg">Where ancient Ayurveda meets your everyday glow.</p>
            <Link to="/shop" className="inline-block rounded-full bg-primary px-7 py-3 text-xs uppercase tracking-widest text-primary-foreground transition hover:bg-accent hover:text-accent-foreground">
              Shop Now
            </Link>
          </div>
        </div>
      </section>

      <div className="overflow-hidden border-y border-border bg-band py-3 sm:py-4">
        <div className="flex w-max animate-marquee gap-8 whitespace-nowrap font-display text-base tracking-[0.15em] text-secondary sm:text-xl">
          {Array.from({ length: 10 }).map((_, i) => (
            <span key={i} className="flex items-center gap-8">The Art of Ayurveda <Sparkle className="h-3.5 w-3.5 text-accent" /></span>
          ))}
        </div>
      </div>

      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-24 md:px-10">
        <div className="mb-10 flex items-end justify-between sm:mb-12">
          <h2 className="font-display text-4xl sm:text-5xl md:text-6xl">The Collection</h2>
          <Link to="/shop" className="shrink-0 text-xs uppercase tracking-widest text-accent">View all</Link>
        </div>
        <div className="grid gap-10 md:grid-cols-3">
          {products.map((p) => <ProductCard key={p.name} p={p} />)}
        </div>
      </section>

      <section className="bg-card py-16 sm:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 md:px-10">
          <p className="text-xs uppercase tracking-widest text-accent">Glowzo Rituals</p>
          <h2 className="mb-4 mt-3 font-display text-4xl sm:text-5xl">See the glow.</h2>
          <p className="mb-10 text-sm text-muted-foreground sm:mb-12">Tap a video to play it with sound. Tap again to pause.</p>
          <Rituals />
        </div>
      </section>

      <Footer />
    </main>
  );
}
