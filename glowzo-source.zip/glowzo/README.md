# GLOWZO website source

All pages, cart, WhatsApp ordering, photos and videos are included. Media files are stored locally in public/media, and the image/video pointers are updated for this download.

## Run
Install current Node.js LTS and Bun, then open this folder in a terminal:

```sh
bun install
bun run dev
```

Open the local address printed in the terminal.

## Commands
- bun run test: run tests
- bun run build: production build
- bun run preview: preview production build

## Files
- src/routes: website pages
- src/lib/products.ts: product catalog
- src/lib/cart.ts: cart totals and WhatsApp order message
- src/lib/cart-context.ts: shared cart connection
- src/components/cart.tsx: cart display
- src/components/site.tsx: header, footer, product cards
- src/styles.css: styles
- public/media: images and videos

WhatsApp number: +91 99883 34117. The cart is temporary, with no customer accounts. Confirm the contact email and policy wording before use. Dependency folders, credentials, Git metadata and compiled build output are excluded.
